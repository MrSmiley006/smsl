# noinspection PyUnresolvedReferences
from ujson import *
