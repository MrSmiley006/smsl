# noinspection PyUnresolvedReferences
from uheapq import *
