# https://github.com/MightyPirates/OpenComputers/blob/master-MC1.12/
# - src/main/resources/assets/opencomputers/loot/openos/lib/shell.lua
# - src/main/resources/assets/opencomputers/loot/openos/lib/core/full_shell.lua


from process import spawn

__all__ = ["spawn"]
