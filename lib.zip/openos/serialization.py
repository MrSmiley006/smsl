# https://github.com/MightyPirates/OpenComputers/blob/master-MC1.12/
# - src/main/resources/assets/opencomputers/loot/openos/lib/serialization.lua

__all__ = ["serialize", "unserialize"]


def serialize(value, pretty=False):
    raise NotImplementedError


def unserialize(value):
    raise NotImplementedError


raise NotImplementedError
